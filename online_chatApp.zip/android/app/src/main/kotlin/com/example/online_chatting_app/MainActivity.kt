package com.example.online_chatting_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
